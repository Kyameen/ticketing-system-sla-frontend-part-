class RolePolicy {
  final String? type; // 'company' | 'client' | 'system_admin'
  final String?
  sub; // e.g. 'Admin' | 'Manager' | 'User' | 'client_manager' | 'client_user'

  RolePolicy({required this.type, required this.sub});

  bool get isCompany => type == 'company';
  bool get isClient => type == 'client';

  // Today’s rules:
  bool get clientCanCreateTicket =>
      isClient; // both client_manager + client_user
  bool get companyCanCreateTicket =>
      false; // disabled until backend supports it
}
