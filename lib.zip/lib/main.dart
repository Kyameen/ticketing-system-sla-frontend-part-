import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'services/api_client.dart';
import 'services/auth_service.dart';
import 'services/ticket_service.dart';

import 'providers/auth_provider.dart';
import 'providers/ticket_provider.dart';

import 'screens/login_screen.dart';
import 'screens/role_router.dart';

void main() {
  // Build our service graph once
  final api = ApiClient();
  final authService = AuthService(api);
  final ticketService = TicketService(api);

  runApp(
    MultiProvider(
      providers: [
        // Must come first so TicketProvider can read it
        ChangeNotifierProvider<AuthProvider>(
          create: (_) => AuthProvider(authService),
        ),
        // Needs both TicketService and the AuthProvider from above
        ChangeNotifierProvider<TicketProvider>(
          create: (ctx) =>
              TicketProvider(ticketService, ctx.read<AuthProvider>()),
        ),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.read<AuthProvider>();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ticketing MVP',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: FutureBuilder(
        future: auth.init(), // loads saved token if any
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          return auth.isLoggedIn ? const RoleRouter() : const LoginScreen();
        },
      ),
    );
  }
}
