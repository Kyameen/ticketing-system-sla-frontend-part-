import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/ticket_provider.dart';
import '../../models/ticket.dart';

class TicketListScreen extends StatefulWidget {
  const TicketListScreen({super.key});

  @override
  State<TicketListScreen> createState() => _TicketListScreenState();
}

class _TicketListScreenState extends State<TicketListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<TicketProvider>().refresh();
    });
  }

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<TicketProvider>();
    final items = prov.items;

    return Scaffold(
      appBar: AppBar(title: const Text('My Tickets')),
      body: prov.isLoading && items.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: prov.refresh,
              child: ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(12),
                itemBuilder: (_, i) => _TicketTile(items[i]),
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemCount: items.length,
              ),
            ),
    );
  }
}

class _TicketTile extends StatelessWidget {
  final Ticket t;
  const _TicketTile(this.t);

  @override
  Widget build(BuildContext context) {
    final sub = TextStyle(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
    );
    return Card(
      child: ListTile(
        title: Text(t.subject),
        subtitle: Text(
          t.description,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: sub,
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (t.statusId != null) Text('Status: ${t.statusId}', style: sub),
            Text('ID: ${t.id}', style: sub),
          ],
        ),
      ),
    );
  }
}
