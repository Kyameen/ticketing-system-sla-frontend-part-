import 'dart:convert';

import '../models/ticket.dart';
import 'api_client.dart';

class TicketService {
  final ApiClient api;
  TicketService(this.api);

  // ---- helpers ----
  Map<String, dynamic> _safeMap(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return Map<String, dynamic>.from(value);
    return <String, dynamic>{};
  }

  Map<String, dynamic> _asMap(String body) {
    try {
      return _safeMap(jsonDecode(body));
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  String? _message(String body) {
    try {
      final m = _asMap(body);
      final v = m['message'];
      return v?.toString();
    } catch (_) {
      return null;
    }
  }

  /// GET tickets visible to the current user.
  /// If your backend uses a dedicated route for clients, tweak the path below.
  Future<List<Ticket>> listMine({bool forClient = false}) async {
    final path = forClient ? '/tickets?mine=1' : '/tickets';

    // DEBUG: log request
    // ignore: avoid_print
    print('[TicketService] GET $path');

    final res = await api.get(path);

    // DEBUG: log response
    // ignore: avoid_print
    print('[TicketService] -> status=${res.statusCode}');
    // ignore: avoid_print
    print('[TicketService] -> body=${res.body}');

    if (res.statusCode ~/ 100 != 2) {
      throw Exception(
        _message(res.body) ?? 'Failed to fetch tickets (${res.statusCode})',
      );
    }

    // Accept either { data: [...] } or a plain [...]
    dynamic decoded;
    try {
      decoded = jsonDecode(res.body);
    } catch (_) {
      decoded = null;
    }

    List<dynamic> rawList;
    if (decoded is List) {
      rawList = decoded;
    } else if (decoded is Map && decoded['data'] is List) {
      rawList = decoded['data'] as List;
    } else {
      rawList = const [];
    }

    // DEBUG: how many items parsed
    // ignore: avoid_print
    print('[TicketService] items=${rawList.length}');

    return rawList
        .whereType<Map>()
        .map((e) => Ticket.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  /// POST /tickets — create a ticket
  Future<Ticket> create({
    required String subject,
    required String description,
    int? priorityId,
    int? categoryId,
    int? departmentId,
    // For client users company_id/client_id are injected on backend.
    int? companyId,
    int? clientId,
    int? agreementId,
  }) async {
    final body = <String, dynamic>{
      'subject': subject,
      'description': description,
      if (priorityId != null) 'priority_id': priorityId,
      if (categoryId != null) 'category_id': categoryId,
      if (departmentId != null) 'department_id': departmentId,
      if (companyId != null) 'company_id': companyId,
      if (clientId != null) 'client_id': clientId,
      if (agreementId != null) 'agreement_id': agreementId,
    };

    // DEBUG: log request
    // ignore: avoid_print
    print('[TicketService] POST /tickets body=$body');

    final res = await api.post('/tickets', body);

    // DEBUG: log response
    // ignore: avoid_print
    print('[TicketService] POST /tickets -> status=${res.statusCode}');
    // ignore: avoid_print
    print('[TicketService] body=${res.body}');

    if (res.statusCode ~/ 100 != 2) {
      throw Exception(
        _message(res.body) ?? 'Create ticket failed (${res.statusCode})',
      );
    }

    final decoded = _asMap(res.body);
    final data = _safeMap(decoded['data']);

    return Ticket.fromJson(data);
  }
}
